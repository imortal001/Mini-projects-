import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Form } from '../types/form';

const API_URL = 'http://your-backend-url/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const FormService = {
  async createForm(formData: Partial<Form>) {
    const response = await api.post('/forms', formData);
    return response.data;
  },

  async getForm(formId: string) {
    const response = await api.get(`/forms/${formId}`);
    return response.data;
  },

  async submitResponse(formId: string, responses: any) {
    const response = await api.post(`/forms/${formId}/responses`, responses);
    return response.data;
  },
};