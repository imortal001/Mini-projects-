import React from 'react';
import { View, TextInput, Switch, Text } from 'react-native';
import tw from 'twrnc';
import { Question } from '../../types/form';

interface QuestionEditorProps {
  question: Question;
  onUpdate: (updatedQuestion: Question) => void;
}

export const QuestionEditor: React.FC<QuestionEditorProps> = ({
  question,
  onUpdate,
}) => {
  const handleTitleChange = (title: string) => {
    onUpdate({ ...question, title });
  };

  const handleRequiredToggle = () => {
    onUpdate({ ...question, required: !question.required });
  };

  const handleOptionsChange = (options: string[]) => {
    onUpdate({ ...question, options });
  };

  return (
    <View style={tw`p-4 bg-white rounded-lg shadow-sm`}>
      <TextInput
        style={tw`border border-gray-300 rounded-md p-2 mb-4`}
        value={question.title}
        onChangeText={handleTitleChange}
        placeholder="Question Title"
      />
      
      <View style={tw`flex-row items-center mb-4`}>
        <Text style={tw`flex-1`}>Required</Text>
        <Switch
          value={question.required}
          onValueChange={handleRequiredToggle}
        />
      </View>

      {(question.type === 'checkbox' || question.type === 'grid') && (
        <View style={tw`mb-4`}>
          {question.options?.map((option, index) => (
            <TextInput
              key={index}
              style={tw`border border-gray-300 rounded-md p-2 mb-2`}
              value={option}
              onChangeText={(text) => {
                const newOptions = [...(question.options || [])];
                newOptions[index] = text;
                handleOptionsChange(newOptions);
              }}
              placeholder={`Option ${index + 1}`}
            />
          ))}
        </View>
      )}
    </View>
  );
};