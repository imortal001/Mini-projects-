import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import tw from 'twrnc';

interface GridQuestionProps {
  title: string;
  rows: string[];
  columns: string[];
  selectedCells: { [key: string]: string };
  onSelectCell: (row: string, column: string) => void;
  required?: boolean;
}

export const GridQuestion: React.FC<GridQuestionProps> = ({
  title,
  rows,
  columns,
  selectedCells,
  onSelectCell,
  required,
}) => {
  return (
    <View style={tw`mb-4`}>
      <Text style={tw`text-lg font-semibold mb-2`}>
        {title} {required && <Text style={tw`text-red-500`}>*</Text>}
      </Text>
      <ScrollView horizontal>
        <View>
          <View style={tw`flex-row`}>
            <View style={tw`w-20`} />
            {columns.map((column, index) => (
              <View key={index} style={tw`w-20 p-2`}>
                <Text style={tw`text-center font-medium`}>{column}</Text>
              </View>
            ))}
          </View>
          {rows.map((row, rowIndex) => (
            <View key={rowIndex} style={tw`flex-row`}>
              <View style={tw`w-20 p-2`}>
                <Text>{row}</Text>
              </View>
              {columns.map((column, colIndex) => (
                <TouchableOpacity
                  key={colIndex}
                  style={tw\`w-20 h-20 border border-gray-300 \${
                    selectedCells[`${row}-${column}`] ? 'bg-blue-500' : 'bg-white'
                  }\`}
                  onPress={() => onSelectCell(row, column)}
                />
              ))}
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};