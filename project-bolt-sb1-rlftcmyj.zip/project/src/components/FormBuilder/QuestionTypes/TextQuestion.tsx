import React from 'react';
import { View, TextInput, Text } from 'react-native';
import tw from 'twrnc';

interface TextQuestionProps {
  title: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}

export const TextQuestion: React.FC<TextQuestionProps> = ({
  title,
  value,
  onChange,
  required,
}) => {
  return (
    <View style={tw`mb-4`}>
      <Text style={tw`text-lg font-semibold mb-2`}>
        {title} {required && <Text style={tw`text-red-500`}>*</Text>}
      </Text>
      <TextInput
        style={tw`border border-gray-300 rounded-md p-2`}
        value={value}
        onChangeText={onChange}
        placeholder="Enter your answer"
      />
    </View>
  );
};