import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import tw from 'twrnc';

interface CheckboxQuestionProps {
  title: string;
  options: string[];
  selectedOptions: string[];
  onToggleOption: (option: string) => void;
  required?: boolean;
}

export const CheckboxQuestion: React.FC<CheckboxQuestionProps> = ({
  title,
  options,
  selectedOptions,
  onToggleOption,
  required,
}) => {
  return (
    <View style={tw`mb-4`}>
      <Text style={tw`text-lg font-semibold mb-2`}>
        {title} {required && <Text style={tw`text-red-500`}>*</Text>}
      </Text>
      {options.map((option, index) => (
        <TouchableOpacity
          key={index}
          style={tw`flex-row items-center my-1`}
          onPress={() => onToggleOption(option)}
        >
          <View
            style={tw\`w-6 h-6 border-2 border-gray-400 rounded mr-2 \${
              selectedOptions.includes(option) ? 'bg-blue-500' : 'bg-white'
            }\`}
          />
          <Text style={tw`text-base`}>{option}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};