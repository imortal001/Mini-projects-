import React from 'react';
import { View, Text } from 'react-native';
import tw from 'twrnc';

interface ErrorDisplayProps {
  errors: string[];
}

export const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ errors }) => {
  if (!errors.length) return null;

  return (
    <View style={tw`bg-red-100 p-4 rounded-lg mb-4`}>
      {errors.map((error, index) => (
        <Text key={index} style={tw`text-red-700 mb-1`}>
          • {error}
        </Text>
      ))}
    </View>
  );
};