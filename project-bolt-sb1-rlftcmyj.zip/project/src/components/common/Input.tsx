import React from 'react';
import { TextInput, TextInputProps, View, Text } from 'react-native';
import tw from 'twrnc';

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({ 
  label, 
  error, 
  style, 
  ...props 
}) => {
  return (
    <View style={tw`mb-4`}>
      {label && (
        <Text style={tw`text-sm font-medium text-gray-700 mb-1`}>
          {label}
        </Text>
      )}
      <TextInput
        style={[
          tw`border rounded-md p-2`,
          error ? tw`border-red-500` : tw`border-gray-300`,
          style
        ]}
        {...props}
      />
      {error && (
        <Text style={tw`text-red-500 text-sm mt-1`}>
          {error}
        </Text>
      )}
    </View>
  );
};