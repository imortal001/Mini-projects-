import React from 'react';
import { TouchableOpacity, Text, TouchableOpacityProps } from 'react-native';
import tw from 'twrnc';

interface ButtonProps extends TouchableOpacityProps {
  variant?: 'primary' | 'secondary';
  title: string;
}

export const Button: React.FC<ButtonProps> = ({ 
  variant = 'primary', 
  title, 
  style, 
  ...props 
}) => {
  const baseStyle = variant === 'primary' 
    ? tw`bg-blue-500` 
    : tw`bg-gray-500`;

  return (
    <TouchableOpacity
      style={[tw`p-3 rounded-md`, baseStyle, style]}
      {...props}
    >
      <Text style={tw`text-white text-center font-semibold`}>
        {title}
      </Text>
    </TouchableOpacity>
  );
};