import { Form, Question } from '../types/form';

export const validateForm = (form: Form): string[] => {
  const errors: string[] = [];

  if (!form.title) {
    errors.push('Form title is required');
  }

  form.questions.forEach((question, index) => {
    if (!question.title) {
      errors.push(`Question ${index + 1} title is required`);
    }

    if (question.type === 'checkbox' && (!question.options || question.options.length === 0)) {
      errors.push(`Question ${index + 1} must have at least one option`);
    }

    if (question.type === 'grid' && (!question.options || question.options.length < 2)) {
      errors.push(`Question ${index + 1} must have at least one row and one column`);
    }
  });

  return errors;
};

export const validateResponse = (form: Form, responses: any): string[] => {
  const errors: string[] = [];

  form.questions.forEach((question) => {
    if (question.required) {
      const response = responses[question.id];
      
      if (!response) {
        errors.push(`${question.title} is required`);
      } else if (question.type === 'checkbox' && response.length === 0) {
        errors.push(`Please select at least one option for ${question.title}`);
      }
    }
  });

  return errors;
};