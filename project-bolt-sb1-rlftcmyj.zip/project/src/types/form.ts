export interface Question {
  id: string;
  type: 'text' | 'grid' | 'checkbox';
  title: string;
  imageUrl?: string;
  options?: string[];
  required: boolean;
}

export interface Form {
  id: string;
  title: string;
  description?: string;
  headerImage?: string;
  questions: Question[];
  createdAt: Date;
  updatedAt: Date;
}