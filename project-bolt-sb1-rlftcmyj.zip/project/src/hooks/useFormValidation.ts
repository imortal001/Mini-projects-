import { useState, useCallback } from 'react';
import { validateForm, validateResponse } from '../utils/validation';
import { Form } from '../types/form';

export const useFormValidation = (form: Form) => {
  const [errors, setErrors] = useState<string[]>([]);

  const validateFormData = useCallback(() => {
    const newErrors = validateForm(form);
    setErrors(newErrors);
    return newErrors.length === 0;
  }, [form]);

  const validateFormResponse = useCallback((responses: any) => {
    const newErrors = validateResponse(form, responses);
    setErrors(newErrors);
    return newErrors.length === 0;
  }, [form]);

  return {
    errors,
    validateFormData,
    validateFormResponse,
    clearErrors: () => setErrors([])
  };
};