import * as React from 'react';
import * as ReactNativeScript from 'react-nativescript';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { FormBuilder } from './screens/FormBuilder';
import { FormPreview } from './screens/FormPreview';

const Stack = createNativeStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="FormBuilder">
        <Stack.Screen 
          name="FormBuilder" 
          component={FormBuilder}
          options={{ title: 'Create Form' }}
        />
        <Stack.Screen 
          name="FormPreview" 
          component={FormPreview}
          options={{ title: 'Preview Form' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

ReactNativeScript.start(React.createElement(App, {}, null));