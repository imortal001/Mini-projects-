import React from 'react';
import { ScrollView, View, Text } from 'react-native';
import tw from 'twrnc';
import { Form } from '../types/form';
import { TextQuestion } from '../components/FormBuilder/QuestionTypes/TextQuestion';
import { CheckboxQuestion } from '../components/FormBuilder/QuestionTypes/CheckboxQuestion';
import { GridQuestion } from '../components/FormBuilder/QuestionTypes/GridQuestion';

interface FormPreviewProps {
  form: Form;
  onSubmit: (responses: any) => void;
}

export const FormPreview: React.FC<FormPreviewProps> = ({ form, onSubmit }) => {
  const [responses, setResponses] = React.useState<any>({});

  const handleSubmit = () => {
    onSubmit(responses);
  };

  return (
    <ScrollView style={tw`flex-1 bg-white p-4`}>
      <Text style={tw`text-2xl font-bold mb-2`}>{form.title}</Text>
      {form.description && (
        <Text style={tw`text-gray-600 mb-4`}>{form.description}</Text>
      )}
      
      {form.questions.map((question) => (
        <View key={question.id} style={tw`mb-6`}>
          {question.type === 'text' && (
            <TextQuestion
              title={question.title}
              value={responses[question.id] || ''}
              onChange={(value) => 
                setResponses({ ...responses, [question.id]: value })
              }
              required={question.required}
            />
          )}
          {question.type === 'checkbox' && (
            <CheckboxQuestion
              title={question.title}
              options={question.options || []}
              selectedOptions={responses[question.id] || []}
              onToggleOption={(option) => {
                const current = responses[question.id] || [];
                const updated = current.includes(option)
                  ? current.filter((o: string) => o !== option)
                  : [...current, option];
                setResponses({ ...responses, [question.id]: updated });
              }}
              required={question.required}
            />
          )}
          {question.type === 'grid' && (
            <GridQuestion
              title={question.title}
              rows={question.options?.slice(0, question.options.length / 2) || []}
              columns={question.options?.slice(question.options.length / 2) || []}
              selectedCells={responses[question.id] || {}}
              onSelectCell={(row, column) => {
                const current = responses[question.id] || {};
                const key = `${row}-${column}`;
                setResponses({
                  ...responses,
                  [question.id]: {
                    ...current,
                    [key]: !current[key]
                  }
                });
              }}
              required={question.required}
            />
          )}
        </View>
      ))}
    </ScrollView>
  );
};