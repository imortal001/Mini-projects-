import React, { useState } from 'react';
import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import tw from 'twrnc';
import { TextQuestion } from '../components/FormBuilder/QuestionTypes/TextQuestion';
import { CheckboxQuestion } from '../components/FormBuilder/QuestionTypes/CheckboxQuestion';
import { GridQuestion } from '../components/FormBuilder/QuestionTypes/GridQuestion';
import { Question } from '../types/form';

export const FormBuilder = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [headerImage, setHeaderImage] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);

  const addQuestion = (type: 'text' | 'grid' | 'checkbox') => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      type,
      title: '',
      required: false,
      options: type === 'checkbox' ? ['Option 1'] : undefined,
    };
    setQuestions([...questions, newQuestion]);
  };

  return (
    <ScrollView style={tw`flex-1 bg-white p-4`}>
      <View style={tw`mb-6`}>
        <Text style={tw`text-2xl font-bold mb-4`}>Create Form</Text>
        
        <TextInput
          style={tw`border border-gray-300 rounded-md p-2 mb-4`}
          value={title}
          onChangeText={setTitle}
          placeholder="Form Title"
        />

        <TextInput
          style={tw`border border-gray-300 rounded-md p-2 mb-4`}
          value={description}
          onChangeText={setDescription}
          placeholder="Form Description"
          multiline
        />

        <TouchableOpacity
          style={tw`bg-blue-500 p-3 rounded-md mb-4`}
          onPress={() => {/* Implement image picker */}}
        >
          <Text style={tw`text-white text-center`}>Add Header Image</Text>
        </TouchableOpacity>
      </View>

      <View style={tw`mb-6`}>
        <Text style={tw`text-xl font-semibold mb-4`}>Questions</Text>
        
        {questions.map((question, index) => (
          <View key={question.id} style={tw`mb-4 p-4 border border-gray-200 rounded-md`}>
            {/* Question rendering based on type */}
          </View>
        ))}

        <View style={tw`flex-row justify-around mt-4`}>
          <TouchableOpacity
            style={tw`bg-green-500 p-3 rounded-md flex-1 mx-2`}
            onPress={() => addQuestion('text')}
          >
            <Text style={tw`text-white text-center`}>Add Text</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={tw`bg-green-500 p-3 rounded-md flex-1 mx-2`}
            onPress={() => addQuestion('grid')}
          >
            <Text style={tw`text-white text-center`}>Add Grid</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={tw`bg-green-500 p-3 rounded-md flex-1 mx-2`}
            onPress={() => addQuestion('checkbox')}
          >
            <Text style={tw`text-white text-center`}>Add Checkbox</Text>
          </TouchableOpacity>
        </View>
      </View>

      <TouchableOpacity
        style={tw`bg-blue-500 p-4 rounded-md mb-8`}
        onPress={() => {/* Implement form save */}}
      >
        <Text style={tw`text-white text-center text-lg font-semibold`}>Save Form</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};