import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { FormBuilder } from './src/screens/FormBuilder';
import { FormPreview } from './src/screens/FormPreview';
import { StatusBar } from 'expo-status-bar';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <>
      <StatusBar style="auto" />
      <NavigationContainer>
        <Stack.Navigator 
          initialRouteName="FormBuilder"
          screenOptions={{
            headerStyle: {
              backgroundColor: '#f8fafc',
            },
            headerShadowVisible: false,
          }}
        >
          <Stack.Screen 
            name="FormBuilder" 
            component={FormBuilder}
            options={{ title: 'Create Form' }}
          />
          <Stack.Screen 
            name="FormPreview" 
            component={FormPreview}
            options={{ title: 'Preview Form' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}